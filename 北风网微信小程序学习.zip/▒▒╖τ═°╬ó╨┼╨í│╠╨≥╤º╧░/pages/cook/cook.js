// pages/cook/cook.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    indexmenu:[
      {
        "icon":"../../images/icon_01.png",
        "url":"food",
        "text":"众创空间"
      },
      {
        "icon":"../../images/icon_03.png",
        "url":'message',
        "text":'咨询我们'
      },
      {
        "icon":"../../images/icon_07.png",
        "url":'me',
        "text":'我的空间'
      }
    ],
    array:[]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var array = this.initData();

  },
  initData:function(){
    var array = [];
    var obj1 = new Object();
    obj1.img = '../../images/list/goods.png';
    obj1.title = '爱心';
    obj1.type = '健康';
    obj1.liulan = '1024';
    obj1.pingluy = '10';
    array.push(obj1);
    var obj2 = new Object();
    obj1.img = '../../images/list/s4.png';
    obj1.title = '咖啡';
    obj1.type = '医生';
    obj1.liulan = '1024';
    obj1.pingluy = '10';
    array.push(obj2);
    return array;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})